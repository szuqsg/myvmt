package hk.com.mtr.mmis.transfer.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/***
 * used to connect to 3057
 * @author Tony
 *
 */
public class SFTPUtil {

	private static final Log logger = LogFactory.getLog(SFTPUtil.class);
	
	public static String StagingShareFolder="";
	public static String StagingRetentionFolder="";
	public static String ToC3057Folder="";
	public static String C3057ShareFolder="";
	public static String C3057RetentionFolder="";
	public static String C3057IP="";
	public static int C3057Port=22;
	public static String C3057UserName="";
	public static String C3057Password="";
	public static int RetryCount=5;
	public static ChannelSftp sftp=null;
	public static String TempFileSuffix="";
	
	static{	
		StagingShareFolder=PropertiesUtil.getPropertiesValue("StagingShareFolder");
		StagingRetentionFolder=PropertiesUtil.getPropertiesValue("StagingRetentionFolder");
		ToC3057Folder=PropertiesUtil.getPropertiesValue("ToC3057Folder");
		C3057ShareFolder=PropertiesUtil.getPropertiesValue("C3057ShareFolder");
		C3057RetentionFolder=PropertiesUtil.getPropertiesValue("C3057RetentionFolder");
		C3057IP=PropertiesUtil.getPropertiesValue("C3057IP");
		C3057Port=Integer.parseInt(PropertiesUtil.getPropertiesValue("C3057Port"));
		C3057UserName=PropertiesUtil.getPropertiesValue("C3057UserName");
		C3057Password=PropertiesUtil.getPropertiesValue("C3057Password");
		RetryCount=Integer.parseInt(PropertiesUtil.getPropertiesValue("RetryCount"));
		TempFileSuffix=PropertiesUtil.getPropertiesValue("TempFileSuffix");
		
		logger.info("start "+new Date());
		logger.info("StagingShareFolder:"+StagingShareFolder);
		logger.info("C3057ShareFolder:"+C3057ShareFolder); 
		logger.info("C3057RetentionFolder:"+C3057RetentionFolder); 
		logger.info("C3057IP:"+C3057IP); 
		logger.info("C3057Port:"+C3057Port); 
		logger.info("C3057UserName:"+C3057UserName); 
		logger.info("C3057Password:"+C3057Password); 
	}
	

	/**
	 * process file in special folder
	 */
	public static void SFTPManipulateFile(String fileName) throws GeneralException{		
		logger.info( "SFTP found file:"+fileName); 
		try{
			if(fileName.length()>0){
				sftpLogin();
				FileUtil.renameFile(StagingShareFolder+fileName,StagingShareFolder+fileName+TempFileSuffix);
				uploadFile(C3057ShareFolder, fileName);
				changeRemoteFileName(C3057ShareFolder, fileName);
				sftpLogOut();
				
				//delete file in StagingShareFolder folder
				FileUtil.deleteFolder(SFTPUtil.StagingShareFolder);
//				FileUtil.deleteFile(SFTPUtil.StagingShareFolder +fileName+".nmrstemp");
			}	
		}catch (Exception e) {
			sftpLogOut();
			e.printStackTrace() ;
			logger.error("SFTP Manipulate File: " +fileName + " exception! " + e.getMessage());
			//backup file to StagingRetentionFolder
//			moveLocalFile(StagingShareFolder+"\\"+fileName,StagingRetentionFolder);
//			moveLocalFile(StagingShareFolder+"\\"+fileName+".nmrstemp",StagingRetentionFolder);
		}				
	}
	
	
	/**
	 * connect to sftp
	 * @return 
	 */
	public static ChannelSftp sftpLogin() throws GeneralException{
		try {
			JSch jsch = new JSch();
			jsch.getSession(C3057UserName, C3057IP, C3057Port);
			Session sshSession = jsch.getSession(C3057UserName, C3057IP, C3057Port);
//			logger.info("Session created.");
			sshSession.setPassword(C3057Password);
			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			sshSession.setConfig(sshConfig);
			sshSession.connect();
//			logger.info("Session connected.");
//			logger.info("Opening Channel.");
			Channel channel = sshSession.openChannel("sftp");
			channel.connect();
			sftp = (ChannelSftp) channel;
			logger.info("SFTP user: " + C3057UserName + " login server:"+C3057IP+" successfully!");
		} catch (Exception e) {
//			e.printStackTrace() ;
			logger.error("SFTP user: " +C3057UserName + " login server:"+C3057IP+" failed! " + e.getMessage());
			throw new GeneralException("login SFTP server failed!");	
		}
		return sftp;
	}

	public static void sftpLogOut(){
		if(sftp!=null){
			try{
				sftp.getSession().disconnect();
				logger.info("SFTP user: " + C3057UserName + " logout server successfully!");
			}catch(Exception e){
//				e.printStackTrace();
				logger.error("SFTP user: " +C3057UserName + " logout server failed! " + e.getMessage());
			}
		}
	}
	
	
	/**
	 * upload file to special folder
	 */
	public static void uploadFile(String RemoteDirectory, String fileName) throws GeneralException{
		try {
			sftp.cd(RemoteDirectory);
			File file=new File(StagingShareFolder+fileName+TempFileSuffix);
			sftp.put(new FileInputStream(file), file.getName());
			logger.info("SFTP upload File "+fileName+" to "+RemoteDirectory+" successfully!");
		} catch (Exception e) {
			FileUtil.renameFile(StagingShareFolder+fileName+TempFileSuffix,StagingShareFolder+fileName);
//			e.printStackTrace();
			logger.error("SFTP upload File "+fileName+" to "+RemoteDirectory+" failed! " + e.getMessage());
			throw new GeneralException("SFTP upload File "+fileName+" to "+RemoteDirectory+" failed! " + e.getMessage());
		}
	}

	
	/**
	 * change Remote FileName
	 */
	public static void changeRemoteFileName(String directory, String fileName) throws GeneralException{
		try {
			sftp.cd(directory);
			sftp.rename(fileName+TempFileSuffix, fileName);
			logger.info("SFTP change remote fileName to "+directory+fileName+" successfully!");
		} catch (Exception e) {
			FileUtil.renameFile(StagingShareFolder+fileName+TempFileSuffix,StagingShareFolder+fileName);
//			e.printStackTrace();
			logger.error("SFTP change remote fileName to "+directory+fileName+" failed! " + e.getMessage());
			throw new GeneralException("SFTP change remote fileName failed!");
		}
	}

	/**
	 * list all files of the special folder
	 */
	@SuppressWarnings("unchecked")
	public static Vector<LsEntry> listFiles(String directory) throws SftpException{
		return sftp.ls(directory);
	}

}
