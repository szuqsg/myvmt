package hk.com.mtr.mmis.transfer.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/***
 * used to keep common method
 * @author Tony
 *
 */
public class WebUtil {
			
	public static SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	/**
	 * get current datetime
	 */
	public static String getDateTimeNow(){
		return sdf2.format(new Date());
	}
	
	/**
	 * check the date format of the file name
	 */
	public static boolean isDate(String fileName){
		try{
		String time=fileName.substring(fileName.lastIndexOf(".")-14,fileName.lastIndexOf("."));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = sdf.parse(time);
		String newTime = sdf.format(date);
		return true;
		}catch(Exception e){
			return false;
		}		
	}
	
}
