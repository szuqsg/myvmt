package hk.com.mtr.mmis.transfer.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/***
 * used to get Value in the Properties file  
 * @author Tony
 *
 */
public class PropertiesUtil {
	private static Properties properties;
	
	public PropertiesUtil(){		
	}
	
	//init
	static{		
		InputStream in =null;
		try{
			in = PropertiesUtil.class.getResourceAsStream("/system.properties");
			properties = new Properties();
			properties.load(in);
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(in !=null){
				try{
					in.close();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
		
	/**
	 * get Properties Value by key
	 */
	public static String getPropertiesValue(String key){		
		String value = (String) properties.get(key);
		if(value ==null){
			return "";
		}
		return value;
	}
	
	public static void main(String[] args){
		PropertiesUtil s = new PropertiesUtil();
		System.out.println("\u8f49\u66f4 "+PropertiesUtil.getPropertiesValue("TempFileSuffix"));
		System.out.println("12345 "+(PropertiesUtil.getPropertiesValue("Ecn4Port1ee")==""));
	
	}
}
