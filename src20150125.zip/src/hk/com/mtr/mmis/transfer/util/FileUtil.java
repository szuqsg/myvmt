package hk.com.mtr.mmis.transfer.util;

import java.io.*; 

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/***
 * used to Manipulate File 
 * @author Tony
 *
 */
public class FileUtil {
	
	private static final Log logger = LogFactory.getLog(FileUtil.class);
	
	public static String fromPath="";
	public static String toPath="";
	public static String backUpPath="";
	
	static{	
		fromPath  =PropertiesUtil.getPropertiesValue("FromFolder");
		toPath    =PropertiesUtil.getPropertiesValue("ToFolder");
		backUpPath=PropertiesUtil.getPropertiesValue("BackUpFolder");
	}
	

	/**
	 * find file in special path
	 */
	public static String findFile(String filePath){
		String fileName="";
		try { 
			File findFilePath = new File(filePath); 
			File[] files = findFilePath.listFiles(); 
			logger.info("ToC507Folder files length:"+files.length);
			for (int i = 0; i < files.length; i++) { 
				if (files[i].isDirectory()) { 
					logger.info("directory !"+files[i]);
				} else { 					
					String tempFileName=files[i].getName();
					logger.info("file ! "+tempFileName); 
					//file name should include (Saloon,Undercar), (All,Up,Down), and .gzip
					if((tempFileName.contains("Saloon")||tempFileName.contains("Undercar"))
							&&(tempFileName.contains("Up")||tempFileName.contains("Down"))
							&&(WebUtil.isDate(tempFileName))
							&&(tempFileName.substring(tempFileName.lastIndexOf(".")+1)).equals("gzip")){
						
						logger.info("get file:"+tempFileName);
						fileName=tempFileName;
						break;
					}else if(tempFileName.contains(" SystemLogNMS")
							&&(WebUtil.isDate(tempFileName))
							&&(tempFileName.length()==31)
							&&(tempFileName.substring(tempFileName.lastIndexOf(".")+1)).equals("gzip")){
						
						fileName=tempFileName;
						break;
					}else{
						deleteFile(filePath+tempFileName);
					}
				} 
			} 
		 }catch (Exception e) { 
			 logger.error("findFile error!"); 
			 e.printStackTrace(); 
			 }  
		return fileName;
	}
		
	/**
	 * move file in special path
	 */
	public static void moveFile(String oldFilePath,String newPath){
		 int byteread = 0; 
		 File oldfile = new File(oldFilePath); 
		 try { 
		 if (oldfile.exists()) { //文件存在时 
			 FileInputStream inStream = new FileInputStream(oldfile); //读入原文件 
			 FileOutputStream outStream = new FileOutputStream(new File(newPath,oldfile.getName())); 
			 byte[] buffer = new byte[5120]; 
			 while ( (byteread = inStream.read(buffer)) != -1) {  
				 outStream.write(buffer, 0, byteread); 
			 } 
			 outStream.flush(); 
			 outStream.close(); 
			 inStream.close(); 	

			//delete old file
			 oldfile.delete();
			 } 		   
		 }catch (Exception e) { 
		 logger.info("move file error!"); 
		 e.printStackTrace(); 
		 }  
	}
	
	/**
	 * copy file in special path
	 */
	public static void copyFile(String oldFilePath,String newPath){
		 int byteread = 0; 
		 File oldfile = new File(oldFilePath); 
		 try { 
		 if (oldfile.exists()) { 
			 FileInputStream inStream = new FileInputStream(oldfile); //读入原文件 
			 FileOutputStream outStream = new FileOutputStream(new File(newPath,oldfile.getName())); 
			 byte[] buffer = new byte[5120]; 
			 while ( (byteread = inStream.read(buffer)) != -1) { 
				 outStream.write(buffer, 0, byteread); 
			 } 
			 outStream.flush(); 
			 outStream.close(); 
			 inStream.close(); 	
			 } 
		 }catch (Exception e) { 
		 logger.info("copy file error!"); 
		 e.printStackTrace(); 
		 }  
	}
	
	/**
	 * delete file in special path
	 */
	public static void deleteFile(String fileName){
		 File deletefile = new File(fileName); 
		 try {  
		     //delete old file
			 deletefile.delete();
			 logger.info(" delete file1 "+fileName+" successfully!");
		 }catch (Exception e) { 
		 logger.info("delete file error!"); 
		 e.printStackTrace(); 
		 }  
	}
	
	/**
	 * delete folder in special path
	 */
	public static void deleteFolder(String path){
		File delfile=new File(path); 
		File[] files=delfile.listFiles(); 
		for(int i=0;i<files.length;i++){ 
				files[i].delete(); 
				logger.info(" delete file2 "+files[i].getName()+" successfully!");
		}
	}
	
	/**
	 * rename file in special path
	 */
	public static void renameFile(String fromFileName, String toFileName){
		 File oldFile = new File(fromFileName); 
		 File newFile = new File(toFileName); 
		 logger.info("rename File to "+toFileName+" successfully!"); 
		 try {  
		     //rename file
			 oldFile.renameTo(newFile);			
		 }catch (Exception e) { 
		 logger.info("rename file to "+toFileName+" error!"); 
		 e.printStackTrace(); 
		 }  
	}
	
	/**
	 * rename file prefix in special path
	 */
	public static void renameFilePre(String fromFileName, String toFileName){
		 File oldFile = new File(fromFileName); 
		 File newFile = new File(fromFileName+"retry"); 
		 logger.info("findFile!"+oldFile.getName()); 
		 try {  
		     //rename file
			 oldFile.renameTo(newFile);
		 }catch (Exception e) { 
		 logger.info("rename file error!"); 
		 e.printStackTrace(); 
		 }  
	}
	

}
