package hk.com.mtr.mmis.transfer.util;

import java.io.File;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import it.sauronsoftware.ftp4j.FTPClient;
import it.sauronsoftware.ftp4j.FTPFile;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/***
 * used to connect to C3056
 * @author Tony
 *
 */
public class FTPSUtil {

	private static final Log logger = LogFactory.getLog(FTPSUtil.class);
	
	public static String C3056ShareFolder="";
	public static String C3056RetentionFolder="";
	public static String StagingShareFolder="";
	public static FTPClient ftpClient=new FTPClient();
	public static String C3056IP="";
	public static int C3056Port=21;
	public static String C3056UserName="";
	public static String C3056Password="";
	
	static{	
		C3056ShareFolder  =PropertiesUtil.getPropertiesValue("C3056ShareFolder");
		C3056RetentionFolder    =PropertiesUtil.getPropertiesValue("C3056RetentionFolder");
		StagingShareFolder=PropertiesUtil.getPropertiesValue("StagingShareFolder");
		C3056IP=PropertiesUtil.getPropertiesValue("C3056IP");
		C3056Port=Integer.parseInt(PropertiesUtil.getPropertiesValue("C3056Port"));
		C3056UserName=PropertiesUtil.getPropertiesValue("C3056UserName");
		C3056Password=PropertiesUtil.getPropertiesValue("C3056Password");
		
		logger.info("start "+new Date());
		logger.info("C3056ShareFolder:"+C3056ShareFolder); 
		logger.info("C3056RetentionFolder:"+C3056RetentionFolder); 
		logger.info("StagingShareFolder:"+StagingShareFolder); 
		
		logger.info("C3056IP:"+C3056IP); 
		logger.info("C3056Port:"+C3056Port); 
		logger.info("C3056UserName:"+C3056UserName); 
		logger.info("C3056Password:"+C3056Password); 
	}			

	/**
	 * process file in special folder
	 */
	public static String FTPSManipulateFile() throws GeneralException{
		boolean isLogin=ftpLogin();
		String fileName="";
		if(isLogin==true){		
			fileName=findFile("");
			logger.info("FPTS found file:"+fileName); 
			if(fileName.length()>0){
				downloadFile(fileName,fileName,C3056ShareFolder, StagingShareFolder);
				uploadFile(StagingShareFolder+fileName,C3056RetentionFolder);
				deleteFile(fileName, C3056ShareFolder) ;
			}
		ftpLogOut();		
		}
				
		return fileName;
	}
	

	
	/**
	 * download file in special folder
	 */
	public static boolean downloadFile(String remoteFileName,String localFileName,
			String remotePath, String localPath) throws GeneralException{
		String strFilePath = localPath + localFileName;
		boolean success = false;
		try {
			ftpClient.changeDirectory(remotePath);
			ftpClient.download(remoteFileName, new File(strFilePath));
			logger.info("FPTS start to download file: "+remoteFileName);
			success = true;			 
			if (success == true) {
				logger.info("FPTS download file: "+remoteFileName + " successfully to " + strFilePath);
				return success;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("FPTS download file: "+remoteFileName +" exception! "+ e.getMessage());
			throw new GeneralException("FPTS download file exception!");		
		} 
//		if (success == false) {
//			logger.info(remoteFileName + "FPTS download failed!");
//		}
		return success;
	}
	
	/**
	 * upload file in special folder
	 */
	public static boolean uploadFile(String localFilePath, String remoteUpLoadPath) throws GeneralException{
		File localFile=new File(localFilePath);
		boolean success = false;
		try {
			ftpClient.changeDirectory(remoteUpLoadPath);
			ftpClient.upload(localFile);
			success = true;
			if (success == true) {
				logger.info("FPTS upload file: "+localFilePath + " successfully to " + remoteUpLoadPath);				
				return success;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("FPTS upload file: "+localFilePath +" exception! "+ e.getMessage());
			//move file to FromC3056Folder
			//FileUtil.moveFile(oldFilePath, newPath);
			throw new GeneralException("FPTS upload file exception!");	
		} 
		
//		if (success == false) {
//			logger.info(localFile + " upload failed!");
//		}
		return success;
	}
	    
	
	/**
	 * delete file in special folder
	 */
	public static boolean deleteFile(String remoteFileName, String remotePath) throws GeneralException{

		boolean successfully = false;
		try {
			ftpClient.changeDirectory(remotePath);
			ftpClient.deleteFile(remoteFileName);		
			successfully = true;
			if (successfully == true) {
				logger.info("FPTS delete file: "+remoteFileName + " successfully in " + remotePath);				
				return successfully;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("FPTS delete file: "+remoteFileName + " excetpion "+ e.getMessage());
			//move file to FromC3056Folder
			//FileUtil.moveFile(oldFilePath, newPath);
			throw new GeneralException("FPTS delete file exception!");
		} 

		return successfully;
	}
	
	
	/**
	 * change fileName in special folder
	 */
	public static boolean changeFileName(String fromFileName, String toFileName,String remoteDownLoadPath) {
	
		boolean success = false;
		try {
			ftpClient.changeDirectory(remoteDownLoadPath);
			logger.info(fromFileName + " start to changeFileName....");
			ftpClient.rename(fromFileName, toFileName);			 
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.warn("file: "+fromFileName + " change fileName excetpion "+ e.getMessage());
		} finally {

		}
		
		return success;
	}

		
	/**
	 * find file in special folder
	 */
	public static String findFile(String remoteDirectory) throws GeneralException{
		String fileName = "";
		try {			
			FTPFile[] allFile = ftpClient.list();
			logger.info("C3056ShareFolder files length :"+allFile.length);
			for (int currentFile = 0; currentFile < allFile.length; currentFile++) {					
					String tempFileName=allFile[currentFile].getName();
//					logger.info("FPTS found file:"+tempFileName);
					//file name should include (Saloon,Undercar), (Up,Down), and .gzip
					if((tempFileName.contains("Saloon")||tempFileName.contains("Undercar"))
						&&(tempFileName.contains("Up")||tempFileName.contains("Down"))
						&&(WebUtil.isDate(tempFileName))
						&&(tempFileName.substring(tempFileName.lastIndexOf(".")+1)).equals("zip")){
//						logger.info("get file:"+tempFileName);
						
						fileName=tempFileName;
						break;
					}else if(tempFileName.contains(" SystemLogNMS")
							&&(WebUtil.isDate(tempFileName))
							&&(tempFileName.length()==31)
							&&(tempFileName.substring(tempFileName.lastIndexOf(".")+1)).equals("zip")){
						
						fileName=tempFileName;
						break;
					}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("FPTS find file exception! "+e.getMessage());
			throw new GeneralException("FPTS find file exception!");				
		}
		return fileName;
	}
	
	
	/**
	 * @ftp login
	 * */
	public static boolean ftpLogin() throws GeneralException{
		boolean isLogin = false;
		try {
			TrustManager[] trustManager = new TrustManager[] { new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs,String authType) {
				}
				public void checkServerTrusted(X509Certificate[] certs,String authType) {
				}
			} };
			SSLContext sslContext = null;
			sslContext = SSLContext.getInstance("SSL");
			sslContext.init(null, trustManager, new SecureRandom());
			SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
			ftpClient.setSSLSocketFactory(sslSocketFactory);
			ftpClient.setSecurity(FTPClient.SECURITY_FTPS);
			ftpClient.connect(C3056IP, C3056Port);
			ftpClient.login(C3056UserName, C3056Password);

			logger.info("FTPS user:" +C3056UserName + " login server:"+C3056IP+" successfully! ");
			isLogin = true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("FTPS user:" +C3056UserName + " login FTPS server:"+C3056IP+" failed! " + e.getMessage());
			throw new GeneralException("login FTPS server failed!");	
		}

		return isLogin;
	}

	/**
	 * @ftp logout
	 * */
	public static void ftpLogOut() throws GeneralException {
		if (ftpClient!=null) {
			try {
				ftpClient.logout();					
			} catch (Exception e) {
				e.printStackTrace();
				logger.warn("logout FTPS server exception! " + e.getMessage());
			} finally {
				if (ftpClient.isConnected()) { // 断开连接
					try {
					ftpClient.disconnect(true);
					} catch (Exception e) {
						e.printStackTrace();
						logger.warn("FTPS logout server exception! " + e.getMessage());
					}							
				}
			}
		}
	}
	
	

}
