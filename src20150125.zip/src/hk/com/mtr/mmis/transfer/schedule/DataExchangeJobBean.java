package hk.com.mtr.mmis.transfer.schedule;

import hk.com.mtr.mmis.transfer.process.DataExchangeProcess;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * Schedule Job Entrance for file transfer
 * 
 * @version 1.00 02-July-2015
 * @author Tony
 * 
 */
@DisallowConcurrentExecution
public class DataExchangeJobBean extends QuartzJobBean {

	/**
	 * Get Log Instance
	 */
	private static final Log logger = LogFactory.getLog(DataExchangeJobBean.class);

	/**
	 * Declare a PurgeProcess which is included the business logic for Purge
	 */
	@Resource
	private DataExchangeProcess dp;

	/**
	 * Injected RequestProcess by Spring
	 * 
	 * @param rp
	 */
	public void setdp(DataExchangeProcess dp) {
		this.dp = dp;
		
	}

	/**
	 * Execute the actual job. The job data map will already have been applied
	 * as bean property values by execute. The contract is exactly the same as
	 * for the standard Quartz execute method.
	 */
	@Override
	protected void executeInternal(JobExecutionContext arg0)
			throws JobExecutionException {
				
		try {
			dp.executeProcess();

		} catch (Exception e) {
			logger.error("Exception : ", e);
		}

	}

}
