package hk.com.mtr.mmis.transfer.process;

import hk.com.mtr.mmis.transfer.util.FTPSUtil;
import hk.com.mtr.mmis.transfer.util.FileUtil;
import hk.com.mtr.mmis.transfer.util.SFTPUtil;

import java.util.Hashtable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

/**
 * Process for file transfer
 * 
 * @version 1.00 02-July-2015
 * @author Tony
 * 
 */
@Service
public class DataExchangeProcess {

	String executing="false";
	private static final Log logger = LogFactory.getLog(DataExchangeProcess.class);	
	//retry count counter
	public static Hashtable retryCountHT=new Hashtable();
	
	public static void main(String[] args) {
		  ApplicationContext ctx = new ClassPathXmlApplicationContext("springMVC-servlet.xml");   
//		DataExchangeProcess dataex=new DataExchangeProcess();
//		dataex.executeProcess();
	
	}
	
	/**
	 * The main executive method
	 */
	public void executeProcess() {
				
		logger.info("********************* Data dataExchange Start *********************");
		if(executing.endsWith("false")){
		executing="true";	
		String fileName="";
		
		try{		
						
			//check if folder StagingShareFolder have files, if so,retry
			fileName=FileUtil.findFile(SFTPUtil.StagingShareFolder);
			if(fileName.length()<=0){
				//process file from C3056 to Staging server
				fileName=FTPSUtil.FTPSManipulateFile();
				//process file from Staging server to C3057 
				SFTPUtil.SFTPManipulateFile(fileName);
				
			}else{
				boolean continueProcess=false;
				int tempRetryCount=0;
				System.out.println("retryCountHTretryCountHT "+retryCountHT.get(fileName));
				if(retryCountHT.get(fileName)==null){
					retryCountHT.put(fileName, 1);
				
					logger.info("file "+fileName+" had retry 0 time!");
					continueProcess=true;
				}else{
					tempRetryCount=Integer.parseInt(retryCountHT.get(fileName).toString());
					if(tempRetryCount<=SFTPUtil.RetryCount){
						continueProcess=true;
						//retry count add 1
						retryCountHT.put(fileName, tempRetryCount+1);
						logger.info("file "+fileName+" had retry "+tempRetryCount+" times!");
					}else{
						//move file to StagingRetentionFolder, or it will continue to process for ever.
						FileUtil.moveFile(SFTPUtil.StagingShareFolder+fileName,SFTPUtil.StagingRetentionFolder);
						logger.info("file "+fileName+" had retry more than"+tempRetryCount+" times! it will move to "+SFTPUtil.StagingRetentionFolder);
						//remove the retry count in the hash table
						retryCountHT.remove(fileName);
					}
					
				}
				
				if(continueProcess==true){
				//process file from Staging server to C3057	
				SFTPUtil.SFTPManipulateFile(fileName);

				}
			}						
		}catch(Exception e){
//			e.printStackTrace();
			logger.error(e);	
			executing="false";	
		}finally{
			executing="false";	
		}

		}else{
		logger.info("******* Data dataExchange Job is executing, waiting for next time**********");
		}
		logger.info("********************* Data dataExchange End   *********************");
	}

	
			
}
