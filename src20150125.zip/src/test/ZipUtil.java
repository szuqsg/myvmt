package test;

import java.io.*;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;

//import org.apache.commons.compress.archivers.*;
//import org.apache.commons.compress.archivers.jar.*;
//import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
//import org.apache.commons.compress.utils.IOUtils;
//import org.apache.commons.io.FileUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import java.util.zip.GZIPInputStream;  
import java.util.zip.GZIPOutputStream;  

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

public class ZipUtil {
	
	private static final Log logger = LogFactory.getLog(ZipUtil.class);
	
	 private static final String PATH_SEP = "\\";
	 public static final int BUFFER = 5120;

	public static void main(String[] args) {
		try{
		logger.info("start "+new Date());
		String str1="D:\\Logs\\report.zip"; //\\1.txt
		String str2="D:\\Logs\\ToFolder";
//		String str3="D:\\Logs\\testfolder\\TractorVMT3.log";
//		WarUtil.unzip("g:\\data.war", "g:\\data");
//		WarUtil.unzip(str1, str2);
//		WarUtils.zip("g:\\cba.war", "g:\\data");  
//		WarUtil.zip(str1, str2);
		
//		unzipFiles(str1, str2);
		
//		String zipFileName="report2.zip"; //\\1.txt
//		String zipFilePath="D:\\Logs\\ToFolder\\";
//		String fileList="cc2.csv;QCVMT.log;TractorVMT.log;";
////		File files[]=
//		zipFiles(zipFilePath,zipFileName, fileList);
		
		logger.info("end "+new Date());
		}catch (Exception e) { 
			 logger.info("WarUtil error!"); 
			 e.printStackTrace(); 
			 } 
	}
	
	
	
	public static void zipFiles(String zipFilePath,String zipfileName,String fileList) {
        try {
            BufferedInputStream origin = null;
            FileOutputStream dest = new FileOutputStream(zipFilePath+zipfileName);
            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(dest));
            byte data[] = new byte[BUFFER];
            String[] splitFile=fileList.split(";");	    
            for( int i=0;i<splitFile.length;i++){
           	    logger.info(splitFile[i]+" : "+splitFile[i]);           	 	                		                		                	
                File file = new File(zipFilePath+splitFile[i]);

                FileInputStream fi = new FileInputStream(file);
                origin = new BufferedInputStream(fi, BUFFER);
                ZipEntry entry = new ZipEntry(splitFile[i]);
                out.putNextEntry(entry);
                int count;
                logger.info(i+" zipFiles!"); 
                while ((count = origin.read(data,0, BUFFER)) != -1) {
                    out.write(data,0,  count);
                }
                origin.close();
            }
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	
//	public static void zipFiles2() {
//        try {
//            BufferedInputStream origin = null;
//            FileOutputStream dest = new FileOutputStream("D:\\Logs\\myfiles.zip");
//            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(
//                    dest));
//            byte data[] = new byte[BUFFER];	    
//           
//              File f = new File("D:\\Logs\\ToFolder\\");
//            File files[] = f.listFiles();
//
//            for (int i =0 ; i < files.length; i++) {
//                FileInputStream fi = new FileInputStream(files[i]);
//                origin = new BufferedInputStream(fi, BUFFER);
//                ZipEntry entry = new ZipEntry(files[i].getName());
//                out.putNextEntry(entry);
//                int count;
//                logger.info(i+" zipFiles!"); 
//                while ((count = origin.read(data,0, BUFFER)) != -1) {
//                    out.write(data,0,  count);
//                }
//                origin.close();
//            }
//            out.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

	
	public static void unzipFiles(String fileName,String filePath) {
        try {
            ZipFile zipFile = new ZipFile(fileName);
            Enumeration emu = zipFile.entries();
            int i=0;
            while(emu.hasMoreElements()){
            	
                ZipEntry entry = (ZipEntry)emu.nextElement();
                logger.info("entry!"+entry); 
                //会把目录作为一个file读出一次，所以只建立目录就可以，之下的文件还会被迭代到。
                if (entry.isDirectory())
                {
                    new File(filePath , entry.getName()).mkdirs();
                    continue;
                }
                BufferedInputStream bis = new BufferedInputStream(zipFile.getInputStream(entry));
                File file = new File(filePath , entry.getName());
                logger.info("file!"+file.getAbsolutePath()); 
                //加入这个的原因是zipfile读取文件是随机读取的，这就造成可能先读取一个文件
                //而这个文件所在的目录还没有出现过，所以要建出目录来。
                File parent = file.getParentFile();
                if(parent != null && (!parent.exists())){
                    parent.mkdirs();
                }
                FileOutputStream fos = new FileOutputStream(file);
                BufferedOutputStream bos = new BufferedOutputStream(fos,BUFFER);           
                
                int count;
                byte data[] = new byte[BUFFER];
                while ((count = bis.read(data,0,BUFFER)) != -1)
                {
//                	logger.info("count!"+count); 
                    bos.write(data, 0, count);
                }
                bos.flush();
                bos.close();
                bis.close();
            }
            zipFile.close();
        } catch (Exception e) {
        	logger.info("WarUtil error!"); 
            e.printStackTrace();
        }
    }
	
}
