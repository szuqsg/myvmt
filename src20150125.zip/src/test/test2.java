package test;

import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory; 

import org.w3c.dom.Document; 
import org.w3c.dom.Element; 
import org.w3c.dom.NodeList; 

import java.lang.reflect.Proxy;
import java.lang.reflect.InvocationHandler;;

public class test2  { 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testDOM dom4j=new testDOM();
//		Document document =dom4j.parserXmlFile("D:\\project\\FileTransfer\\src\\test\\readme.xml");
//		System.out.println("return: "+getPropertyFromXMLFile(document,"logging_data","file"));
//		System.out.println("return: "+getPropertyFromXMLFile(document,"Schedule","name"));

//		ArrayList alist=getPropertyListFromXMLFile(document,"soundwave","figure");
//		for (int i = 0; i < alist.size(); i++) { 
//			String returnString=(String)alist.get(i);
//			System.out.println(" propertyName: "+i +"  "+ returnString);	
//			
//			}
		String strT="TRACK	LINE	CURVE NO	RADIUS	START KM	END KM	TRACK LENGTH	HIGH RIAL SIDE	CANT	SPEED	SUPPORT	HRSECT	LRSECT	HRGRADE	LRGRADE";
		String[] splie=strT.split(" ");
		for(int i=0;i<splie.length;i++){
			System.out.println(splie[i]);	
		}
		System.out.println(" done: ");	
	}
	

	public static String getPropertyFromXMLFile(Document document,String elementName,String attributeName) { 
		String returnString="";
		try { 
			NodeList beanlist=document.getElementsByTagName(elementName);
			
			System.out.println( "sizes "+ beanlist.getLength());
			
			for (int i = 0; i < beanlist.getLength(); i++) { 
				Element bean =(Element) beanlist.item(i); 
				returnString= bean.getAttribute(attributeName);
				break;
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()); 
			}
		System.out.println(" attributeName: "+ returnString);	
		return returnString;
	}
	
	public static ArrayList getPropertyListFromXMLFile(Document document,String elementName,String attributeName) { 
		ArrayList aList=new ArrayList();
		try { 
			NodeList beanlist=document.getElementsByTagName(elementName);
			
			System.out.println( "sizes "+ beanlist.getLength());
			
			for (int i = 0; i < beanlist.getLength(); i++) { 
				Element bean =(Element) beanlist.item(i); 
				String returnString= bean.getAttribute(attributeName);
				System.out.println(" attributeName: "+i +"  "+ returnString);	
				aList.add(returnString);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()); 
				e.printStackTrace();
				} 
		
		return aList;
	}
	

	
	
	
	public Document parserXmlFile(String fileName) { 
		Document document =null;
		try{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
		    
			document = db.parse(fileName);
			
		}catch(Exception e){
			System.out.println("erroge: "+e.getMessage()); 
		}
		return document;
	}
	
}
