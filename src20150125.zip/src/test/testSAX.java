package test;

import java.io.StringReader;                                                                                                                                                                                                                           
import org.dom4j.Document;  
import org.dom4j.Element;                                                                                                                                                                                                                              
import org.dom4j.io.SAXReader;                                                                                                                                                                                                                         
import org.xml.sax.InputSource;                                                                                                                                                                                                                        
public class testSAX {                                                                                                                                                                                                                               
    public static void main(String args[]) {   
//    	org.springframework.orm.hibernate3.LocalSessionFactoryBean
//    	org.springframework.orm.hibernate3.AbstractSessionFactoryBean
//    	org.hibernate.SessionFactory sessionFactory
//        String xml = "<request> <param name='service' ID='tt'>single_trade_query </param><param name='_input_charset'>utf-8 </param><param name='partner'>2088001513232645 </param><param name='out_trade_no'>20090422577264 </param></request>";
    	String xml=select();
        InputSource source = new InputSource(new StringReader(xml));                                                                                                                                                                               
        SAXReader reader = new SAXReader();                                                                                                                                                                                                        
        Document document = null;                                                                                                                                                                                                                  
        try {                                                                                                                                                                                                                                      
            document = reader.read(source);                                                                                                                                                                                                        
        } catch (Exception e) {                                                                                                                                                                                                            
            // TODO Auto-generated catch block                                                                                                                                                                                                     
            e.printStackTrace();                                                                                                                                                                                                                   
        }                                                                                                                                                                                                                                          
        Element root = document.getRootElement();                                                                                                                                                                                                  
        System.out.println("\u53c3\u6578\u4fe1\u606f'\u767b\u9304\u7528\u6236'\u4e0d\u5b58\u5728!!");                                                                                                                                                                              
        System.out.println(root.elementByID("message").getTextTrim());                                                                                                                                                                                  
    }  
    
	 public static String getRequestXML(){
		 StringBuffer requestxml=new StringBuffer();
		  requestxml.append("<?xml version=\"1.0\" encoding=\"US-ASCII\"?> ");
		  requestxml.append(" <message type=\"2632\" MSID=\"2\" formId=\"FORM_UNAVAILABLE\"> ");
		  requestxml.append(" <che CHID=\""+11+"\"> ");
		  requestxml.append(" <pow name=\"K31\" mode=\"Manual\" /> ");
		  requestxml.append(" <pow name=\"K32\" mode=\"Manual\" /> ");
		  requestxml.append(" <pow name=\"K33\" mode=\"Manual\" /> ");
		  requestxml.append(" <pow name=\"K34\" mode=\"Manual\" /> ");
		  requestxml.append(" </che> ");
		  requestxml.append(" </message> ");
		  
		 return requestxml.toString();
	 }
	
	 public static String select(){
		 StringBuffer requestxml=new StringBuffer();
		  requestxml.append("<?xml version=\"1.0\" encoding=\"US-ASCII\"?> ");
		  requestxml.append(" <message type=\"2609\" MSID=\"1\" > ");
		  requestxml.append(" <che CHID=\""+22+"\" />");		
		  requestxml.append(" </message> ");
		  
		 return requestxml.toString();
	 }
}     

