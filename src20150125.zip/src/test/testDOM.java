package test;

import java.io.FileInputStream; 
import java.io.FileNotFoundException; 
import java.io.FileOutputStream; 
import java.io.IOException; 
import java.io.InputStream; 
import java.io.PrintWriter; 
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.xml.parsers.DocumentBuilder; 
import javax.xml.parsers.DocumentBuilderFactory; 
import javax.xml.parsers.ParserConfigurationException; 
import javax.xml.transform.OutputKeys; 
import javax.xml.transform.Transformer; 
import javax.xml.transform.TransformerConfigurationException; 
import javax.xml.transform.TransformerException; 
import javax.xml.transform.TransformerFactory; 
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult; 

import org.w3c.dom.Document; 
import org.w3c.dom.Element; 
import org.w3c.dom.NodeList; 

import org.xml.sax.InputSource;


public class testDOM  { 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testDOM dom4j=new testDOM();
//		dom4j.parserXmlFile("D:\\project\\FileTransfer\\src\\test\\readme.xml");
//		dom4j.parserXmlFile("D:\\project\\FileTransfer\\src\\test\\schedule.xml"); 
//		String ff="LA_EQ_1.25kHz";
		Document document =dom4j.parserXmlFile("D:\\project\\FileTransfer\\src\\test\\readme.xml");
//		System.out.println("return: "+getPropertyFromXMLFile(document,"logging_data","file"));
//		System.out.println("return: "+getPropertyFromXMLFile(document,"Schedule","name"));

//		ArrayList alist=getPropertyListFromXMLFile(document,"soundwave","figure");
//		for (int i = 0; i < alist.size(); i++) { 
//			String returnString=(String)alist.get(i);
//			System.out.println(" propertyName: "+i +"  "+ returnString);	
//			
//			}
		
		Hashtable  ht=new Hashtable();
		ht.put("TIME_SPANE", 1001);
		ht.put("SPEED", 1002);
		ht.put("LaMax", 1003);
		
		System.out.println(ht.get("SPEED"));	
//		String[] testString=new String[20];
//		testString[0]="(";
//		testString[1]="LAFmax >= 95";
//		testString[2]="over 11 TimeSpan";
//		testString[3]="AND";
//		testString[4]="LAFmax > 55";
//		testString[5]=")";
//		testString[6]="OR";
//		testString[7]="(";
//		testString[8]="LAFmax >= 90";
//		testString[9]="over 11 TimeSpan";
//		testString[10]="AND";
//		testString[11]="LAFmax > 50";
//		testString[12]=")";
//		for(int i=0;i<testString.length;i++){
//			logger.info("done "+testString[i]); 
//		}
		String tString="( LAFmax >= 95  over 11 TimeSpan AND LAFmax > 55  ) OR 	( If LAFmax >= 90  over 22 TimeSpan AND LAFmax > 66  ) ";
		
//		System.out.println(" done: ");	
	}
	

	public static String getPropertyFromXMLFile(Document document,String elementName,String attributeName) { 
		String returnString="";
		try { 
			NodeList beanlist=document.getElementsByTagName(elementName);
			
			System.out.println( "sizes "+ beanlist.getLength());
			
			for (int i = 0; i < beanlist.getLength(); i++) { 
				Element bean =(Element) beanlist.item(i); 
				returnString= bean.getAttribute(attributeName);
				break;
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()); 
			}
		System.out.println(" attributeName: "+ returnString);	
		return returnString;
	}
	
	public static ArrayList getPropertyListFromXMLFile(Document document,String elementName,String attributeName) { 
		ArrayList aList=new ArrayList();
		try { 
			NodeList beanlist=document.getElementsByTagName(elementName);
			
			System.out.println( "sizes "+ beanlist.getLength());
			
			for (int i = 0; i < beanlist.getLength(); i++) { 
				Element bean =(Element) beanlist.item(i); 
				String returnString= bean.getAttribute(attributeName);
				System.out.println(" attributeName: "+i +"  "+ returnString);	
				aList.add(returnString);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage()); 
				e.printStackTrace();
				} 
		
		return aList;
	}
	

	
	private Document document; 
	private String fileName;
	
	
	public Document parserXmlFile(String fileName) { 
		Document document =null;
		try{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
		    
			document = db.parse(fileName);
			
		}catch(Exception e){
			System.out.println("erroge: "+e.getMessage()); 
		}
		return document;
	}
	
	
	public void parseDocument2(Document document) { 
		try { 
					
//			NodeList employees = document.getChildNodes();
//			NodeList beanlist=document.getElementsByTagName("pow");
//			NodeList beanlist=document.getElementsByTagName("che");
//			NodeList beanlist=document.getElementsByTagName("pow");		
//			NodeList beanlist=document.getElementsByTagName("displayMsg");
			//get schedule.xml
//			NodeList beanlist=document.getElementsByTagName("schedule");
			//get readme.xml
			NodeList beanlist=document.getElementsByTagName("report");
			
//			NodeList beanlist=document.getElementsByTagName("MessageID");
			System.out.println( "sizes "+ beanlist.getLength());
			
			for (int i = 0; i < beanlist.getLength(); i++) { 
				Element bean =(Element) beanlist.item(i); 
//				
//				System.out.println(bean.getTagName() +"1:"+ bean.getAttribute("id")+" 2:"+ bean.getAttribute("class")+" 3:"+ bean.getAttribute("lazy-init"));
//				System.out.println(bean.getAttribute("formId") +"  message1: "+ bean.getAttribute("ack"));
//				System.out.println(bean.getAttribute("CHID") +"  che1: "+ bean.getAttribute("equipType")+"  3: "+ bean.getAttribute("status"));
//				System.out.println(bean.getAttribute("name") +"  pow1: "+ bean.getAttribute("mode"));
//				System.out.println(bean.getNodeName() +"  ww: "+ bean.getTextContent());
				// get readme.xml
				System.out.println("  readme.xm: "+bean.getAttribute("file") +"  spectrum: "+ bean.getAttribute("spectrum")+"  figure: "+ bean.getAttribute("figure"));
				System.out.println("  root: "+ bean.getAttribute("type")+"  name: "+ bean.getAttribute("name"));
				//get schedule.xml
				System.out.println("  schedule.xml: "+ bean.getAttribute("train_operation_mode")+"  name: "+ bean.getAttribute("name"));
//				System.out.println(bean.getAttribute("msgID") +"  displayMsg: "+ bean.getAttribute("mode"));
				NodeList propertyInfo = bean.getChildNodes();
				
				
//				for (int j = 0; j < propertyInfo.getLength(); j++) { 
//					System.out.println( "property size"+ propertyInfo.getLength());
//					Node beanproperty = propertyInfo.item(j);
////					System.out.println(beanproperty.getNodeName() +":"+ beanproperty.getNodeValue());
//					NodeList employeeMeta = beanproperty.getChildNodes();
//					for (int k = 0; k < employeeMeta.getLength(); k++) { 
//						System.out.println(employeeMeta.item(k).getNodeName() + ":" + employeeMeta.item(k).getTextContent()); 
//						}
//					}
				}
			System.out.println("解析完毕"); 
			} catch (Exception e) {
				System.out.println(e.getMessage()); 
				} 
		
		}
	
	 public static String select(){
		 StringBuffer requestxml=new StringBuffer();
		  requestxml.append("<?xml version=\"1.0\" encoding=\"US-ASCII\"?> ");
		  requestxml.append(" <message type=\"2632\" MSID=\"2\" formId=\"FORM_UNAVAILABLE\"> ");
		  requestxml.append(" <che CHID=\""+11+"\"> ");
		  requestxml.append(" <pow name=\"S31\" mode=\"Manua\" /> ");
		  requestxml.append(" <pow name=\"V32\" mode=\"Manu\" /> ");
		  requestxml.append(" <pow name=\"G33\" mode=\"Man\" /> ");
		  requestxml.append(" <pow name=\"B34\" mode=\"Ma\" /> ");
		  requestxml.append(" </che> ");
		  requestxml.append(" </message> ");
		  
		 return requestxml.toString();
	 }
	
	 public void init() { 
			try {
				DocumentBuilderFactory factory = DocumentBuilderFactory .newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder(); 
				this.document = builder.newDocument(); }
			catch (ParserConfigurationException e) { 
				System.out.println(e.getMessage()); }
			}
		
		public void parserXmlString(String XMLString) { 
			try{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
		    
	        //创建新的输入源SAX 解析器将使用 InputSource 对象来确定如何读取 XML 输入
			StringReader read = new StringReader(XMLString);
	        InputSource source = new InputSource(read);

			Document document = db.parse(source);
			parseDocument2( document);
			}catch(Exception e){
				System.out.println("erroge: "+e.getMessage()); 
			}
		}
		
	public void createXml(String fileName) {
		Element root = this.document.createElement("employees"); 
		this.document.appendChild(root);
		Element employee = this.document.createElement("employee");
		Element name = this.document.createElement("name"); 
		name.appendChild(this.document.createTextNode("丁宏亮"));
		employee.appendChild(name); 
		Element sex = this.document.createElement("sex"); 
		sex.appendChild(this.document.createTextNode("m"));
		employee.appendChild(sex); 
		Element age = this.document.createElement("age");
		age.appendChild(this.document.createTextNode("30"));
		employee.appendChild(age); root.appendChild(employee); 
		TransformerFactory tf = TransformerFactory.newInstance();
		try {
			Transformer transformer = tf.newTransformer();
			DOMSource source = new DOMSource(document); 
			transformer.setOutputProperty(OutputKeys.ENCODING, "gb2312");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			PrintWriter pw = new PrintWriter(new FileOutputStream(fileName)); 
			StreamResult result = new StreamResult(pw); 
			transformer.transform(source, result); 
			System.out.println("生成XML文件成功!"); }
		catch (TransformerConfigurationException e) {
			System.out.println(e.getMessage()); } 
		catch (IllegalArgumentException e) {
			System.out.println(e.getMessage()); } 
		catch (FileNotFoundException e) { 
			System.out.println(e.getMessage()); }
		catch (TransformerException e) { 
			System.out.println(e.getMessage()); } } 
	} 
