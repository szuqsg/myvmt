package test;

import java.util.Date;

import hk.com.mtr.mmis.transfer.util.FTPSUtil;
import hk.com.mtr.mmis.transfer.util.FileUtil;
import hk.com.mtr.mmis.transfer.util.WebUtil;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class testClass {

	private static final Log logger = LogFactory.getLog(testClass.class);
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		logger.info("start "+new Date());
		// TODO Auto-generated method stub
		
		//--------------------FTPSUtil----------------------------------
		FTPSUtil.ftpLogin();

		
		
		
		//--------------------FTPUtil----------------------------------
//		FTPUtil ftp=new FTPUtil("10.199.132.48",21,"nmrs","nmrs");
//		FTPUtil.ftpLogin();
//		String fileName="cc2.csv";
//		String tempFileName=fileName+".nmrstemp";
		
		//find file
//		logger.info( "findFile found:"+FTPUtil.findFile("")); ///New folder
//		FTPUtil.downloadFile(fileName,tempFileName, "d://backup//", "") ;//D://Logs//
//		FTPSUtil.changeFileName(tempFileName, fileName,StagingShareFolder) ;//D://Logs//
//		FTPUtil.deleteFile("cc.csv", "D://Logs//") ;
//		File afile=new File("d://backup//cc2.csv");
//		FTPUtil.uploadFileTemp(afile, "/T123/") ;
//		FTPUtil.uploadFile("d://backup//cc2.csv", "/T123") ;
//		FTPUtil.FTPSManipulateFile();

//		FTPUtil.ftpLogOut();	

//		logger.info("fromPath:"+fromPath); 
//		logger.info("toPath:"+toPath); 
//		logger.info("backUpPath:"+backUpPath); 
		
//		logger.info("startDelay:"+startDelay); 
//		logger.info("backUpPath:"+backUpPath); 
	String str1="D:\\Logs\\report.gzip"; //\\1.txt
	String str2="D:\\Logs\\ToFolder";
	String str3="D:\\Logs\\report.gzip.gzidddpfeer";
	String str4="A123_Undercar_ISL_20111915213527.zip";
	String str5="SystemLogNMS_20111915213527.zip";
//		copyFile(str1,str2);
//		moveFile(str1,str2);
//	renameFile(str1,str3);
//	renameFile(str3,str1);
//	FileUtil.renameFile(StagingShareFolder+"\\"+uploadFile,StagingShareFolder+"\\"+uploadFile+".nmrstemp");
//	renameFilePre(str1,str3);
			  
		//--------------------SFTPUtil----------------------------------
//		changeLocalFileName(StagingShareFolder, downloadFile, changeFileName);  //�����ļ�
//		SFTPUtil sf = new SFTPUtil();
//		ChannelSftp  sftp = sftpLogin();	//��ȡ����.
//		sftpLogin();
////
//		sf.upload(C3507ShareFolder, uploadFile);	//�ϴ��ļ�
//
//		sf.download(C3507ShareFolder, downloadFile, saveFile);  //�����ļ�

//		sf.changeRemoteFileName(C3507ShareFolder, downloadFile, changeFileName);
//	    sf.delete(C3507ShareFolder, deleteFile); //ɾ���ļ�

//				Vector<LsEntry> files = sf.listFiles(C3507ShareFolder); 		//�鿴�ļ��б�
//				for (LsEntry file : files) {  
//					logger.info(file.getFilename());
//				}
		
//		sftpLogOut();
		
		
		
		//--------------------WebUtil----------------------------------

//	       String testStr =" LAFmax >= 11  over 11 TimeSpan AND LAFmax > 22)   OR ( LAFmax >= 33  over 44 TimeSpan AND LAFmax > 66  ) AND false";
//		     String testStr =" true OR (LAFmax >= 33  over 44 TimeSpan AND LAFmax > 66  ) ";
//	       String testStr ="( LAFmax >= 11  over 11 TimeSpan AND LAFmax > 22  ) OR true";
//	       String testStr =" true    AND false";
//			 String testStr ="Pway_chain    >= 33  over 44 TimeSpan ";
//			 String testStr ="LAFmax >= 33  compared with 1 last measurement";
//			 String testStr = " ((8*2)+(4+2)*3+(15-4)*2) ";
			 
//			 while(testStr.contains("(")&&testStr.contains(")")){
//				 testStr=parseExceedanceCriteria(testStr);
//				  System.out.println(" while testStr: "+testStr);;
//			 }
//			String sp1=parseExceedanceCriteria(testStr);
//	       System.out.println("finallyyyyyyyyyy "+sp1);
			 
//			boolean bsp1=validateExceedanceCriteria(testStr);
//	     System.out.println("finallyyyyyyyyyy "+bsp1);
	       
//			 String[] splitStr=StringUtils.splitByWholeSeparator(testStr," ");
//				for(int i = 0; i < splitStr.length; i++){	
//					String tempSplitStr=splitStr[i];
//					System.out.println("tempSplitStr "+i+": "+tempSplitStr);					
//				}
//	        System.out.println("testStr "+testStr); 
	
		logger.info("done "+new Date()); 

	}

	
	
}
